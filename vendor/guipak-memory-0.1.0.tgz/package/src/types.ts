/**
 * Tipos del API publico de guipak-memory (TypeScript client).
 */

export interface ActiveObject {
  objectType: string;        // 'cliente' | 'sku' | 'fp' | 'oc' | 'vendedor' | ...
  objectId: string;
  objectLabel?: string;      // nombre legible
  lastTopic?: string;        // 'saldo' | 'stock' | 'enviar_correo' | ...
  meta?: Record<string, unknown>;
}

export interface ObjectIntelligence {
  metrics: Record<string, unknown>;
  computedAt: Date;
}

/**
 * Interfaz minima que el cliente espera de la conexion MySQL.
 * Compatible con mysql2 (pool y connection).
 */
export interface MysqlExecutor {
  execute(sql: string, params?: unknown[]): Promise<[unknown, unknown]>;
}

export interface GuipakMemoryOptions {
  mysql: MysqlExecutor;
}
