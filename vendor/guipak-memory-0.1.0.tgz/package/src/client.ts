/**
 * GuipakMemory · cliente TypeScript de la memoria conversacional compartida.
 *
 * Espera una conexion mysql2 (pool o connection). Todos los metodos son
 * async. Asume que las migrations 001 y 002 ya estan aplicadas en la base.
 */
import type {
  ActiveObject,
  GuipakMemoryOptions,
  MysqlExecutor,
  ObjectIntelligence,
} from './types.js';

export class GuipakMemory {
  private mysql: MysqlExecutor;

  constructor(opts: GuipakMemoryOptions) {
    this.mysql = opts.mysql;
  }

  // =====================================================
  // Capa 1 · sesion activa
  // =====================================================

  async getActiveObject(supervisor: string, chatId: number): Promise<ActiveObject | null> {
    const [rows] = await this.mysql.execute(
      `SELECT object_type, object_id, object_label, last_topic, meta_json
       FROM agent_session
       WHERE supervisor = ? AND chat_id = ?`,
      [supervisor, chatId],
    );
    const list = rows as Array<Record<string, unknown>>;
    if (!list.length) return null;
    const r = list[0];
    if (!r.object_type || !r.object_id) return null;
    return {
      objectType: String(r.object_type),
      objectId: String(r.object_id),
      objectLabel: r.object_label == null ? undefined : String(r.object_label),
      lastTopic: r.last_topic == null ? undefined : String(r.last_topic),
      meta: this.parseJson(r.meta_json),
    };
  }

  async setActiveObject(supervisor: string, chatId: number, obj: ActiveObject): Promise<void> {
    const metaJson = obj.meta ? JSON.stringify(obj.meta) : null;
    await this.mysql.execute(
      `INSERT INTO agent_session
         (supervisor, chat_id, object_type, object_id, object_label, last_topic, meta_json, updated_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, NOW())
       ON DUPLICATE KEY UPDATE
         object_type = VALUES(object_type),
         object_id = VALUES(object_id),
         object_label = VALUES(object_label),
         last_topic = VALUES(last_topic),
         meta_json = VALUES(meta_json),
         updated_at = NOW()`,
      [
        supervisor,
        chatId,
        obj.objectType,
        obj.objectId,
        obj.objectLabel ?? null,
        obj.lastTopic ?? null,
        metaJson,
      ],
    );
  }

  async clearActiveObject(supervisor: string, chatId: number): Promise<void> {
    await this.mysql.execute(
      `DELETE FROM agent_session WHERE supervisor = ? AND chat_id = ?`,
      [supervisor, chatId],
    );
  }

  // =====================================================
  // Capa 2 · inteligencia del objeto
  // =====================================================

  async getObjectIntelligence(
    supervisor: string,
    objectType: string,
    objectId: string,
  ): Promise<ObjectIntelligence | null> {
    const [rows] = await this.mysql.execute(
      `SELECT metrics_json, computed_at
       FROM agent_object_intelligence
       WHERE supervisor = ? AND object_type = ? AND object_id = ?`,
      [supervisor, objectType, objectId],
    );
    const list = rows as Array<Record<string, unknown>>;
    if (!list.length) return null;
    const r = list[0];
    return {
      metrics: this.parseJson(r.metrics_json) ?? {},
      computedAt: r.computed_at instanceof Date ? r.computed_at : new Date(String(r.computed_at)),
    };
  }

  async upsertObjectIntelligence(
    supervisor: string,
    objectType: string,
    objectId: string,
    metrics: Record<string, unknown>,
  ): Promise<void> {
    await this.mysql.execute(
      `INSERT INTO agent_object_intelligence
         (supervisor, object_type, object_id, metrics_json, computed_at)
       VALUES (?, ?, ?, ?, NOW())
       ON DUPLICATE KEY UPDATE
         metrics_json = VALUES(metrics_json),
         computed_at = NOW()`,
      [supervisor, objectType, objectId, JSON.stringify(metrics)],
    );
  }

  // =====================================================
  // Capa 4 · inyeccion al system prompt
  // =====================================================

  async buildMemorySection(supervisor: string, chatId: number): Promise<string> {
    const active = await this.getActiveObject(supervisor, chatId);
    if (!active) return '';

    const lines: string[] = ['[MEMORIA ACTIVA]'];
    const label = active.objectLabel ?? active.objectId;
    lines.push(`Objeto activo: ${active.objectType.toUpperCase()} ${label} (${active.objectId})`);
    if (active.lastTopic) {
      lines.push(`Ultimo tema: ${active.lastTopic}`);
    }

    const intel = await this.getObjectIntelligence(supervisor, active.objectType, active.objectId);
    if (intel && Object.keys(intel.metrics).length > 0) {
      lines.push('Metricas relevantes:');
      for (const [k, v] of Object.entries(intel.metrics)) {
        lines.push(`  - ${k}: ${this.formatValue(v)}`);
      }
    }

    lines.push('[/MEMORIA ACTIVA]');
    return lines.join('\n');
  }

  // =====================================================
  // Helpers privados
  // =====================================================

  private parseJson(raw: unknown): Record<string, unknown> | undefined {
    if (raw == null) return undefined;
    if (typeof raw === 'object') return raw as Record<string, unknown>;
    if (typeof raw === 'string') {
      try {
        const parsed = JSON.parse(raw);
        return typeof parsed === 'object' && parsed !== null ? parsed : undefined;
      } catch {
        return undefined;
      }
    }
    return undefined;
  }

  private formatValue(v: unknown): string {
    if (typeof v === 'number') {
      return Number.isInteger(v) ? v.toLocaleString('en-US') : v.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
    }
    if (Array.isArray(v)) {
      return v.map(String).join(', ');
    }
    if (v == null) return '';
    return String(v);
  }
}
